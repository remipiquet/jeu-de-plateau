/**
 * Lancement des fonctions
 */
const currentGame = new Game();
currentGame.start();








