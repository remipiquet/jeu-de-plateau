class Weapon {
    constructor(id, name, damage, imgUrl){
        this.id = id;
        this.name = name;
        this.damage = damage;
        this.imgUrl = imgUrl;
    }
}


